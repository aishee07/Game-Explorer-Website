-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2024 at 07:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `astar_games`
--

-- --------------------------------------------------------

--
-- Table structure for table `new_games`
--

CREATE TABLE `new_games` (
  `g_id` int(11) NOT NULL,
  `g_name` varchar(255) NOT NULL,
  `g_category` varchar(255) DEFAULT NULL,
  `g_description` text DEFAULT NULL,
  `g_rating` float DEFAULT NULL,
  `g_image_url` varchar(255) DEFAULT NULL,
  `g_download_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `new_games`
--

INSERT INTO `new_games` (`g_id`, `g_name`, `g_category`, `g_description`, `g_rating`, `g_image_url`, `g_download_url`) VALUES
(1, 'Suicide Squad: Kill the Justice League', 'Action, Superhero', 'Suicide Squad: Kill the Justice League is a third-person shooter where misfits must defeat the Justice League.', 6, 'images/SuicideSquad.jpg', 'https://store.steampowered.com/app/315210/Suicide_Squad_Kill_the_Justice_League/'),
(2, 'Black Myth: Wukong', 'Action, Adventure, RPG', 'A Chinese mythology-based action RPG where you, the Destined One, uncover hidden truths behind a legendary past.', 10, 'images/wukong2.jpg', 'https://store.steampowered.com/app/2358720/Black_Myth_Wukong/'),
(3, 'Star Wars Outlaws', 'Action, Adventure', 'Explore the first-ever open-world *Star Wars™* game as Kay Vess, a scoundrel seeking freedom. Fight, steal, and outwit crime syndicates across iconic and new galactic locations.', 7, 'images/starwars.avif', 'https://store.epicgames.com/en-US/p/star-wars-outlaws'),
(4, 'Skull and Bones', 'Action, Open-World, RPG', 'Set sail in Skull and Bones, a naval action RPG. Customize your fleet, craft unique ships and weapons, and conquer the seas in thrilling battles to become the ultimate pirate kingpin.', 6, 'images/SkullAndBones.jpg', 'https://store.steampowered.com/app/2853730/Skull_and_Bones/'),
(5, 'Harry Potter: Quidditch Champions', 'Fantasy, Sports', 'Your next chapter takes flight! Experience the magic of Quidditch solo or with friends and family.', 8, 'images/quidditch.png', 'https://store.steampowered.com/app/2878600/Harry_Potter_Quidditch_Champions/'),
(6, 'EA SPORTS™ Madden NFL 25', 'Football, ESports', 'Hit hard with *FieldSENSE™* powered by BOOM Tech. Realistic collisions and new animations with dynamic tackling.', 6, 'images/maddenNFL25.jpg', 'https://store.steampowered.com/app/2582560/EA_SPORTS_Madden_NFL_25/'),
(7, 'TEKKEN 8', 'Action, Fighting', 'Get ready for the next chapter in the legendary fighting game franchise, TEKKEN 8.', 7, 'images/tekken.avif', 'https://store.steampowered.com/app/1778820/TEKKEN_8/');

-- --------------------------------------------------------

--
-- Table structure for table `trending_games`
--

CREATE TABLE `trending_games` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `download_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `trending_games`
--

INSERT INTO `trending_games` (`id`, `name`, `category`, `description`, `rating`, `image_url`, `download_url`) VALUES
(1, 'Black Myth: Wukong', 'Action, Adventure, RPG', 'A Chinese mythology-based action RPG where you, the Destined One, uncover hidden truths behind a legendary past.', 10, 'images/wukong2.jpg', 'https://store.steampowered.com/app/2358720/Black_Myth_Wukong/'),
(2, 'Ghost of Tsushima', 'Action, Open-World', 'Experience Ghost of Tsushima DIRECTOR\'S CUT on PC—explore its open world and uncover hidden wonders. ', 9.5, 'images/GhostOfTsushima.jpg', 'https://store.steampowered.com/app/2215430/Ghost_of_Tsushima_DIRECTORS_CUT/'),
(3, 'Hogwarts Legacy', 'Open-World, Fantasy', 'It is an immersive, open-world action RPG. Now you can take control of the action and be at the center of your own adventure in the wizarding world.', 9, 'images/HogwartsLegacy.avif', 'https://store.steampowered.com/app/990080/Hogwarts_Legacy/'),
(4, 'Cyberpunk 2077', 'Action, Open-World, RPG', '*Cyberpunk 2077* is an open-world action RPG set in Night City—a dark, dangerous megalopolis driven by power, glamor, and body modification.', 9, 'images/cyberpunk.webp', 'https://store.steampowered.com/app/1091500/Cyberpunk_2077/'),
(5, 'Grand Theft Auto V', 'Action, Open-World, RPG', 'Players can explore the award-winning world of Los Santos and Blaine County in resolutions up to 4K and enjoy 60 frames per second gameplay.', 9, 'images/gtav.png', 'https://store.steampowered.com/app/271590/Grand_Theft_Auto_V/'),
(6, 'Red Dead Redemption 2', 'Open-World, Action', 'Winner of 175+ Game of the Year Awards and 250+ perfect scores, RDR2 follows outlaw Arthur Morgan and the Van der Linde gang on the run in early America. ', 9, 'images/rdr2.jpg', 'https://store.steampowered.com/app/1174180/Red_Dead_Redemption_2/'),
(7, 'Palworld', 'Open-World, Multiplayer', 'Fight, farm, build and work alongside mysterious creatures called \"Pals\" in this completely new multiplayer, open world survival and crafting game!', 9, 'images/palworld.jpg', 'https://store.steampowered.com/app/1623730/Palworld/'),
(8, 'Forza Horizon 5', 'Racing, Open-World', 'Explore Mexico’s vibrant open world in Forza Horizon 5. Race in Hot Wheels or conquer Sierra Nueva in the Rally Adventure. Base game required; expansions sold separately.', 9, 'images/Forza5.e02f4ead-d89b-45cd-8eb5-5dcbf44ae91f', 'https://store.steampowered.com/app/1551360/Forza_Horizon_5/'),
(9, 'Valorant', 'Action, Co-op, 5v5 shooter', 'Showcase your style on a global stage with sharp gunplay and tactics. Survive 13-round battles in Competitive, Unranked, Deathmatch, or Spike Rush modes.', 9, 'images/valorant.jpg', 'https://store.epicgames.com/en-US/p/valorant'),
(10, 'Resident Evil Village', 'Horror, Action', 'Experience unparalleled horror in *Resident Evil Village* with stunning visuals, intense action, and masterful storytelling.', 10, 'images/REVillage.png', 'https://store.steampowered.com/app/1196590/Resident_Evil_Village/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `trending_games`
--
ALTER TABLE `trending_games`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `trending_games`
--
ALTER TABLE `trending_games`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
